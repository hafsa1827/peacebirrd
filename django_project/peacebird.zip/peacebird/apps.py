from django.apps import AppConfig


class PeacebirdConfig(AppConfig):
    name = 'peacebird'
